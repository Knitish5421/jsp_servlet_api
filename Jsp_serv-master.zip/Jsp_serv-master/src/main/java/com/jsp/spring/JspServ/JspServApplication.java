package com.jsp.spring.JspServ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspServApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspServApplication.class, args);
	}

}
